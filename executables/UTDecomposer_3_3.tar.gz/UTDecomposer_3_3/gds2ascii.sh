#!/bin/bash

# check input parameter
if [ $# -ne 1 ]; then
  echo "Usage: $0 [file name (w/o. gds)]"
  exit
fi

# check gds2Covert exists
if [ ! -d bin/gdsCovert ]; then
  echo "gdsCovert not found!"
  exit
fi

# check wireMerge exists
if [ ! -f bin/wireMerge ]; then
  echo "wireMerge not found!"
  exit
fi

gds_name="$1.gds"
out_name="$1.ascii"

# check gds file exists
if [ ! -f $gds_name ]; then
  echo "File $gds_name not found!"
fi

# ==== main flow
./bin/gdsCovert/gds2txt  $gds_name >  ./tmp.ascii
./bin/wireMerge -in tmp.ascii -out $out_name 
rm -rf tmp.ascii




