#########################################################################
# File Name: runRelease.sh
# Author: Yibo Lin
# mail: yibolin@utexas.edu
# Created Time: Thu 07 Jan 2016 08:00:57 PM CST
#########################################################################
#!/bin/bash

# ==================== options =====================
# stitching is not allowed 
# Gurobi is required to run LP coloring
# -shape, if the input benchmark only contains rectangles, use -shape RECTANGLE; otherwise, use -shape POLYGON
# -simplify_level, 0|1|2
# -thread_num, number of threads 
# -uncolor_layer, target layer for decomposition
# -algo, decomposition algorithm 
# -color_num, 3|4
# -coloring_distance, distance in nm 
# ==================================================

echo "Gurobi is required to run LP coloring"

./SimpleMPL -shape POLYGON \
    -simplify_level 2 \
    -thread_num 8 \
    -uncolor_layer 101 \
    -algo LP \
    -color_num 4 \
    -coloring_distance 160 \
    -in ./bench/sim_s1.gds
